
#ifndef IN_TARGET_VALIDITY
#define IN_TARGET_VALIDITY
#include"../../src/include.h"
using namespace std;

void ValidityCheck(mms shims,Bs B);

void compare_target_and_measured_field(mms shims,Bs B);

















#endif
