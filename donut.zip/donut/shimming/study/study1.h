
#ifndef IN_STUDY1
#define IN_STUDY1
#include"../../src/include.h"
using namespace std;

void enough_size_of_pocket();

void IterationAnalysis(const char* inputfile_root,const char* output_root);

void DistributionAnalysis(const char* inputfile_root,
                          const char* output_root,
                          int i_iteration);














#endif
