
#pragma once

#include"../../src/include.h"
using namespace std;

void ProperStrength();

void U_lc_WorstCase();

void TruncatedEigenmodeDicision();

void v_max_decision();

void scan_BufferRate();

void SymmetryMode();

static void DrawEigenDistribution(Eigen::VectorXd u,const char* ofn_root);

void ShimmingCalculation();

void IronCapacity();

void IronCapacity_start();

void study_20220903();

void study_20220913();

void study_20220914();

void study_20220916();

void study_20220930();




