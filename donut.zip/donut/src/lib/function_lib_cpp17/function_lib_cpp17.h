
#pragma once

#include"../../include.h"
using namespace std;

double ellint_3_lib(double m,double alpha,double phase);

double ellint_1_lib(double m,double phase);

double legendre_lib(double n,double x);

