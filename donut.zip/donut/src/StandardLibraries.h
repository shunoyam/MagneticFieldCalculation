
#pragma once

#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<cstdlib>
#include<math.h>
#include<time.h>
#include<vector>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<cstdio>
#include<numeric>
#include<cmath>
