
#include"../src/include.h"

using namespace std;

void desk()
{

  puts("main macro is written at donut/processor/desk.cpp\n");
  
  magnet _magnet;//initialize object, muon storage magnet
  TVector3 position(.1,0.,2);//[m]
  TVector3 MagneticField=_magnet.B(position);
  cout<<"Calculated magnetic field [T]:";
  cout<<MagneticField.x()<<"\t"<<MagneticField.y()<<"\t"<<MagneticField.z()<<endl;
 
}




